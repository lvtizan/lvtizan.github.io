<?php
defined('ABSPATH') || exit;
function fy_seed_attachment($name,$label,$parent) {
    require_once ABSPATH.'wp-admin/includes/file.php';
    require_once ABSPATH.'wp-admin/includes/media.php';
    require_once ABSPATH.'wp-admin/includes/image.php';
    $source=__DIR__.'/sample/'.$name;
    if (!is_readable($source)) return 0;
    $tmp=wp_tempnam($name);
    if (!$tmp || !copy($source,$tmp)) return 0;
    $id=media_handle_sideload(['name'=>$name,'tmp_name'=>$tmp],$parent,$label);
    if (is_wp_error($id)) { wp_delete_file($tmp); return 0; }
    return $id;
}
function fy_seed() {
    if (get_option('fy_demo_seeded')) return;
    $id=wp_insert_post(['post_type'=>'fy_exhibit','post_status'=>'publish','post_title'=>'FYN1-1','post_content'=>'灰白纹理大板。可查看整板实拍与同型号接待大厅应用图，也可听讲解或上传客厅照片试铺。'],true);
    if (is_wp_error($id)) return;
    foreach (['kind'=>'石材建材','number'=>'FYN1-1','material'=>'石材','sale'=>'仅展示'] as $key=>$value) update_post_meta($id,'_fy_'.$key,$value);
    $assets=[];
    foreach (['cover'=>['hall.webp','接待大厅'],'detail'=>['detail.webp','空间局部'],'board'=>['board.webp','整板长图'],'audio'=>['fyn.mp3','FYN1-1 讲解']] as $key=>[$file,$label]) {
        $assets[$key]=fy_seed_attachment($file,$label,$id);
        if ($assets[$key]) update_post_meta($id,'_fy_'.$key,$assets[$key]);
    }
    update_post_meta($id,'_fy_gallery',implode(',',array_filter([$assets['cover'],$assets['detail']])));
    update_option('fy_demo_seeded',$id,false);
}
