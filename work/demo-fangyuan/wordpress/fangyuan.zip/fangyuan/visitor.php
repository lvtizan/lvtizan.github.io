<?php
defined('ABSPATH') || exit;
$id=absint($_GET['fy_try'] ?? $_GET['exhibit'] ?? 0);
$single=isset($_GET['fy_try']) || isset($_GET['exhibit']);
$item=$single?get_post($id):null;
$available=$item && $item->post_type==='fy_exhibit' && ($item->post_status==='publish' || (isset($_GET['preview']) && current_user_can('edit_post',$id)));
if ($single && (!$available || post_password_required($item))) {
    status_header(404); nocache_headers();
    wp_die('这件展品暂未展示。','方圆石光',['response'=>404,'link_url'=>home_url('/'),'link_text'=>'返回展厅']);
}
$kind=$single?fy_meta($id,'kind'):'';
$cover=$single?wp_get_attachment_url((int)fy_meta($id,'cover')):'';
$board=$single?wp_get_attachment_url((int)fy_meta($id,'board')):'';
if (isset($_GET['fy_try']) && $kind==='石材建材' && ($board || $cover)) {
    $html=file_get_contents(__DIR__.'/studio/index.html');
    $html=str_replace('<head>','<head><base href="'.esc_url(fy_asset('studio/')).'">',$html);
    $html=str_replace('src="assets/fyn1-1.webp"', 'src="'.esc_url($board ?: $cover).'"',$html);
    $html=str_replace('>FYN1-1</span>', '>'.esc_html(get_the_title($id)).'</span>',$html);
    $html=str_replace('>灰白流纹</span>','>当前展品</span>',$html);
    echo $html;
    return;
}
$gallery=isset($_GET['fy_artist']);
$artist_id=$gallery?absint($_GET['fy_artist']):($single?(int)$item->post_author:0);
$artist=$artist_id?get_userdata($artist_id):false;
$selected=sanitize_text_field(wp_unslash($_GET['kind'] ?? ''));
if ($gallery && (!$artist || !in_array('fy_artist', (array)$artist->roles, true))) {
    $published=$artist_id ? get_posts(['post_type'=>'fy_exhibit','post_status'=>'publish','has_password'=>false,'author'=>$artist_id,'meta_key'=>'_fy_kind','meta_value'=>'艺术作品','fields'=>'ids','numberposts'=>1]) : [];
    if (!$published) wp_die('该画廊暂未开放。','方圆石光',['response'=>404]);
}
$heading=$single?get_the_title($id):($gallery?($artist?$artist->display_name.'的画廊':'作品画廊'):'展厅藏品');
status_header(200);
?><!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title><?=esc_html($heading)?> · 方圆石光</title><link rel="stylesheet" href="<?=esc_url(fy_asset('assets/visitor.css'))?>"></head><body>
<header><a href="<?=esc_url(home_url('/'))?>">方圆石光</a><span>线上展厅</span></header><main>
<?php if ($single): ?>
<p class="category"><?=esc_html($kind)?></p><h1><?=esc_html($heading)?></h1>
<?php if ($cover): ?><img class="hero" src="<?=esc_url($cover)?>" alt="<?=esc_attr($heading)?>"><?php endif; ?>
<div class="detail"><section><h2>展品资料</h2><dl>
<?php foreach (fy_fields() as $key=>$label): $v=fy_meta($id,$key); if ($v==='') continue; ?><dt><?=esc_html($label)?></dt><dd><?=esc_html($v)?></dd><?php endforeach; ?></dl>
<?=wp_kses_post(wpautop($item->post_content))?>
<?php if ($url=wp_get_attachment_url((int)fy_meta($id,'audio'))): ?><h3>听讲解</h3><audio controls preload="none" src="<?=esc_url($url)?>"></audio><?php endif; ?>
</section><aside>
<?php if ($board): ?><button id="open-board">查看整板长图</button><dialog id="board"><button id="close-board" autofocus>关闭 ×</button><img src="<?=esc_url($board)?>" alt="整板原图"></dialog><?php endif; ?>
<?php if ($kind==='石材建材' && ($cover || $board)): ?><a class="button" href="<?=esc_url(add_query_arg('fy_try',$id,home_url('/')))?>">试铺到我家</a><?php endif; ?>
<?php if ($kind==='艺术作品' && $artist): ?><a href="<?=esc_url(add_query_arg('fy_artist',$artist_id,home_url('/')))?>"><?=esc_html($artist->display_name)?>的画廊</a><?php endif; ?>
<?php
$shop_id=absint(fy_meta($id,'wc_product'));
$product=$shop_id && function_exists('wc_get_product') ? wc_get_product($shop_id) : null;
if ($product && $product->get_status()==='publish' && $product->is_purchasable() && $product->is_in_stock() && fy_meta($id,'sale')==='在售'): ?>
<a class="button" href="<?=esc_url(get_permalink($shop_id))?>">选购这件展品</a>
<?php endif; ?>
<?php if ($sale=fy_meta($id,'sale')): ?><p><?=esc_html($sale)?></p><?php endif; ?>
<?php if ($price=fy_meta($id,'price')): ?><p>售价 ¥<?=esc_html($price)?></p><?php endif; ?></aside></div>
<?php $media=array_filter(array_map('absint',explode(',',(string)fy_meta($id,'gallery')))); if ($media): ?><h2><?=$kind==='石材建材'?'配套效果图':'展品相册'?></h2><div class="gallery"><?php foreach ($media as $attachment) echo wp_get_attachment_image($attachment,'large'); ?></div><?php endif; ?>
<?php if ($url=wp_get_attachment_url((int)fy_meta($id,'video'))): ?><h2>展品视频</h2><video controls playsinline preload="metadata" src="<?=esc_url($url)?>"></video><?php endif; ?>
<?php $rate=(float)fy_meta($id,'rate'); if ($kind==='石材建材' && $rate>0): ?><section class="quote"><h2>板材用量与估价</h2><p>按实测尺寸估算材料费，加工、运输及安装由展厅另行核价。</p><form id="quote" data-rate="<?=esc_attr($rate)?>"><label>长（米）<input name="length" type="number" min="0.001" step="any" required></label><label>宽（米）<input name="width" type="number" min="0.001" step="any" required></label><label>损耗（%）<input name="loss" type="number" min="0" max="100" step="any" value="0" required></label><button>计算估价</button></form><output id="estimate" aria-live="polite"></output><button hidden id="print">打印 / 存为 PDF</button></section><?php endif; ?>
<?php else: ?><h1><?=esc_html($heading)?></h1>
<?php if ($gallery && $artist) echo wpautop(esc_html($artist->description)); ?>
<?php if (!$gallery): ?><nav><a href="<?=esc_url(home_url('/'))?>">全部</a><?php foreach (FY_TYPES as $type): ?><a href="<?=esc_url(add_query_arg('kind',$type,home_url('/')))?>"><?=esc_html($type)?></a><?php endforeach; ?></nav><?php endif; ?>
<div class="cards"><?php
$page=max(1,absint($_GET['fy_page']??1));
$args=['post_type'=>'fy_exhibit','post_status'=>'publish','has_password'=>false,'posts_per_page'=>24,'paged'=>$page];
if ($gallery) { $args['author__in']=[$artist_id]; $selected='艺术作品'; }
if (in_array($selected,FY_TYPES,true)) $args['meta_query']=[['key'=>'_fy_kind','value'=>$selected]];
$query=new WP_Query($args);
foreach ($query->posts as $entry): ?><a class="card" href="<?=esc_url(fy_url($entry->ID))?>"><?=wp_get_attachment_image((int)fy_meta($entry->ID,'cover'),'large')?><small><?=esc_html(fy_meta($entry->ID,'kind'))?></small><strong><?=esc_html(get_the_title($entry))?></strong></a><?php endforeach; ?>
</div><?php if (!$query->post_count) echo '<p>该分类暂未上架展品。</p>';
if ($page>1) echo '<a href="'.esc_url(add_query_arg('fy_page',$page-1)).'">上一页</a> ';
if ($page<$query->max_num_pages) echo '<a href="'.esc_url(add_query_arg('fy_page',$page+1)).'">下一页</a>';
endif; ?></main><footer>方圆石光 · 数字展厅　<a href="<?=esc_url(admin_url('edit.php?post_type=fy_exhibit'))?>">工作人员入口</a></footer>
<script src="<?=esc_url(fy_asset('assets/visitor.js'))?>" defer></script></body></html>
