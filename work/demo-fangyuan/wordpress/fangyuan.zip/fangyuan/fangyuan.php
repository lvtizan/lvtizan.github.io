<?php
/**
 * Plugin Name: 方圆石光 · 展厅
 * Description: 展品资料、固定二维码、空间试铺与艺术家寄售。
 * Version: 1.0.0
 */
defined('ABSPATH') || exit;
const FY_TYPES = ['石材建材', '水晶手串', '矿石与大摆件', '艺术作品'];
function fy_asset($path) { return plugins_url($path, __FILE__); }
function fy_url($id) { return add_query_arg('exhibit', (int) $id, home_url('/')); }
function fy_meta($id, $name) { return get_post_meta($id, '_fy_' . $name, true); }
function fy_staff() { return current_user_can('edit_others_posts'); }
function fy_register() {
    register_post_type('fy_exhibit', [
        'labels' => ['name'=>'展品','singular_name'=>'展品','add_new'=>'新增展品','add_new_item'=>'新增展品','edit_item'=>'编辑展品','all_items'=>'全部展品'],
        'public'=>true, 'menu_icon'=>'dashicons-art', 'supports'=>['title','editor','author'],
        'capability_type'=>['fy_exhibit','fy_exhibits'], 'map_meta_cap'=>true, 'rewrite'=>false
    ]);
}
add_action('init','fy_register');
register_activation_hook(__FILE__, function () {
    fy_register();
    foreach (['administrator','editor'] as $role_name) {
        $role = get_role($role_name);
        if ($role) foreach (get_post_type_object('fy_exhibit')->cap as $cap) {
            if (!in_array($cap, ['edit_fy_exhibit','read_fy_exhibit','delete_fy_exhibit'], true)) $role->add_cap($cap);
        }
    }
    add_role('fy_artist','展厅艺术家',['read'=>true,'edit_fy_exhibits'=>true,'upload_files'=>true]);
});
add_filter('ajax_query_attachments_args',function ($args) {
    if (in_array('fy_artist', (array)wp_get_current_user()->roles, true) && !fy_staff()) $args['author']=get_current_user_id();
    return $args;
});
function fy_fields() {
    return ['number'=>'展品编号','material'=>'材质 / 创作媒介','origin'=>'产地','spec'=>'尺寸 / 规格','finish'=>'工艺 / 创作年份','location'=>'展出位置'];
}
function fy_business() {
    return ['price'=>'展品售价（元）','rate'=>'板材单价（元/㎡）','wc_product'=>'对应 WooCommerce 商品 ID（可选）','agreement'=>'寄售期限与约定','settle'=>'艺术家结算记录'];
}
function fy_media_fields() {
    return ['cover'=>['封面图','image'], 'board'=>['整板长图','image'], 'gallery'=>['配套图 / 相册','image'], 'video'=>['展示视频','video'], 'audio'=>['讲解录音','audio']];
}
add_action('add_meta_boxes_fy_exhibit',function () {
    add_meta_box('fy_details','展品档案','fy_editor','fy_exhibit','normal','high');
});
function fy_editor($post) {
    wp_nonce_field('fy_save','fy_nonce');
    echo '<div class="fy-fields">';
    $artist = !fy_staff();
    $types = $artist ? ['艺术作品'] : FY_TYPES;
    echo '<label>展品分类<select name="fy[kind]">';
    foreach ($types as $type) echo '<option '.selected(fy_meta($post->ID,'kind'),$type,false).'>'.esc_html($type).'</option>';
    echo '</select></label>';
    foreach (fy_fields() + ($artist ? [] : fy_business()) as $key=>$label) {
        echo '<label>'.esc_html($label).'<input name="fy['.esc_attr($key).']" value="'.esc_attr(fy_meta($post->ID,$key)).'"></label>';
    }
    echo '</div>';
    if (!$artist) {
        echo '<label>销售 / 寄售状态 <select name="fy[sale]">';
        foreach (['仅展示','在售','已预订','已售','已退还'] as $label) echo '<option '.selected(fy_meta($post->ID,'sale'),$label,false).'>'.esc_html($label).'</option>';
        echo '</select></label>';
    } else {
        echo '<p>寄售与结算记录：'.esc_html(fy_meta($post->ID,'settle') ?: '暂无结算记录').'</p>';
    }
    foreach (fy_media_fields() as $key=>[$label,$type]) {
        $ids=array_filter(array_map('absint',explode(',',(string)fy_meta($post->ID,$key))));
        echo '<div class="fy-media" data-type="'.esc_attr($type).'" data-many="'.($key==='gallery'?'1':'0').'"><strong>'.esc_html($label).'</strong>';
        echo '<input type="hidden" name="fy['.esc_attr($key).']" value="'.esc_attr(implode(',',$ids)).'"><ol>';
        foreach ($ids as $id) echo '<li data-id="'.(int)$id.'">'.esc_html(get_the_title($id)).'</li>';
        echo '</ol><button type="button" class="button fy-choose">选择或上传素材</button></div>';
    }
}
add_action('save_post_fy_exhibit',function ($id) {
    if (wp_is_post_revision($id) || !isset($_POST['fy_nonce'],$_POST['fy']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['fy_nonce'])),'fy_save') || !current_user_can('edit_post',$id)) return;
    $input=wp_unslash($_POST['fy']);
    if (!is_array($input)) return;
    $kind=fy_staff() && in_array($input['kind'] ?? '',FY_TYPES,true) ? $input['kind'] : '艺术作品';
    update_post_meta($id,'_fy_kind',$kind);
    foreach (fy_fields() + (fy_staff()?fy_business():[]) as $key=>$label) {
        if (isset($input[$key]) && is_scalar($input[$key])) update_post_meta($id,'_fy_'.$key,sanitize_text_field($input[$key]));
    }
    if (fy_staff() && in_array($input['sale'] ?? '', ['仅展示','在售','已预订','已售','已退还'],true)) update_post_meta($id,'_fy_sale',$input['sale']);
    foreach (fy_media_fields() as $key=>[$label,$type]) {
        if (!isset($input[$key]) || !is_string($input[$key])) continue;
        $ids=[];
        foreach (array_unique(array_filter(array_map('absint',explode(',',$input[$key])))) as $media) {
            $attachment=get_post($media);
            if (!$attachment || $attachment->post_type!=='attachment' || strpos($attachment->post_mime_type,$type.'/')!==0) continue;
            if (!fy_staff() && (int)$attachment->post_author!==get_current_user_id()) continue;
            $ids[]=$media;
            if ($key!=='gallery') break;
        }
        update_post_meta($id,'_fy_'.$key,implode(',',$ids));
    }
});
add_action('admin_enqueue_scripts',function () {
    $screen=get_current_screen();
    if (!$screen || $screen->post_type!=='fy_exhibit') return;
    wp_enqueue_media();
    wp_enqueue_script('fy-qr',fy_asset('assets/qrcode.js'),[],'1.4.4',true);
    wp_enqueue_script('fy-admin',fy_asset('assets/admin.js'),['fy-qr','media-editor'],'1',true);
    wp_enqueue_style('fy-admin',fy_asset('assets/admin.css'),[],'1');
});
add_filter('manage_fy_exhibit_posts_columns',function ($columns) { $columns['fy_qr']='展牌'; return $columns; });
add_action('manage_fy_exhibit_posts_custom_column',function ($column,$id) {
    if ($column==='fy_qr' && get_post_status($id)==='publish')
        echo '<button type="button" class="button fy-qr" data-url="'.esc_url(fy_url($id)).'" data-id="'.(int)$id.'">下载二维码</button>';
},10,2);
add_filter('post_type_link',function ($url,$post) { return $post->post_type==='fy_exhibit'?fy_url($post->ID):$url; },10,2);
add_action('template_redirect',function () {
    if (is_admin() || is_feed() || wp_doing_ajax()) return;
    if (!isset($_GET['exhibit']) && !isset($_GET['fy_artist']) && !isset($_GET['fy_try']) && !is_front_page() && !is_home()) return;
    require __DIR__.'/visitor.php';
    exit;
});
require_once __DIR__.'/seed.php';
register_activation_hook(__FILE__,'fy_seed');
add_action('admin_menu',function () {
    if (!in_array('fy_artist',(array)wp_get_current_user()->roles,true)) return;
    add_menu_page('我的画廊','我的画廊','edit_fy_exhibits','fy_gallery',function () {
        $id=get_current_user_id();
        echo '<div class="wrap"><h1>我的画廊</h1><p><a href="'.esc_url(get_edit_profile_url()).'">编辑个人简介</a> · <a href="'.esc_url(add_query_arg('fy_artist',$id,home_url('/'))).'">查看公开画廊</a> · <a href="'.esc_url(admin_url('post-new.php?post_type=fy_exhibit')).'">提交新作品</a></p>';
        foreach (get_posts(['post_type'=>'fy_exhibit','author'=>$id,'post_status'=>['publish','draft','pending'],'numberposts'=>-1]) as $work) {
            echo '<p>'.esc_html($work->post_title).' · '.esc_html(get_post_status_object($work->post_status)->label).' · '.esc_html(fy_meta($work->ID,'sale')).' '.esc_html(fy_meta($work->ID,'settle')).'</p>';
        }
        echo '</div>';
    },'dashicons-format-gallery');
});
