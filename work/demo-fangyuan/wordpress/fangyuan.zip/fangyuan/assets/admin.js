document.querySelectorAll('.fy-media').forEach(box => {
  const list = box.querySelector('ol');
  const field = box.querySelector('input');
  const many = box.dataset.many === '1';
  function sync() {
    field.value = [...list.children].map(item => item.dataset.id).join(',');
  }
  function controls(item) {
    for (const action of many ? ['上移', '下移', '移除'] : ['移除']) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'button-link';
      button.textContent = action;
      button.onclick = () => {
        if (action === '移除') item.remove();
        if (action === '上移' && item.previousElementSibling) list.insertBefore(item, item.previousElementSibling);
        if (action === '下移' && item.nextElementSibling) list.insertBefore(item.nextElementSibling, item);
        sync();
      };
      item.append(button);
    }
  }
  [...list.children].forEach(controls);
  box.querySelector('.fy-choose').onclick = () => {
    const frame = wp.media({title: box.querySelector('strong').textContent, multiple: many, library: {type: box.dataset.type}});
    frame.on('select', () => {
      if (!many) list.replaceChildren();
      frame.state().get('selection').toJSON().forEach(media => {
        if ([...list.children].some(item => Number(item.dataset.id) === media.id)) return;
        const item = document.createElement('li');
        item.dataset.id = media.id;
        item.textContent = media.title || media.filename;
        list.append(item);
        controls(item);
      });
      sync();
    });
    frame.open();
  };
});
document.querySelectorAll('.fy-qr').forEach(button => button.onclick = () => {
  const qr = qrcode(0, 'M');
  qr.addData(button.dataset.url);
  qr.make();
  const count = qr.getModuleCount();
  const scale = 18;
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = (count + 8) * scale;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#000';
  for (let y = 0; y < count; y++) for (let x = 0; x < count; x++) {
    if (qr.isDark(y,x)) ctx.fillRect((x+4)*scale,(y+4)*scale,scale,scale);
  }
  const link = document.createElement('a');
  link.download = '方圆石光-' + button.dataset.id + '.png';
  link.href = canvas.toDataURL('image/png');
  link.click();
});
