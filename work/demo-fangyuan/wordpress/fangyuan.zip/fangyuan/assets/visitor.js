const board = document.querySelector('#board');
document.querySelector('#open-board')?.addEventListener('click', () => board.showModal());
document.querySelector('#close-board')?.addEventListener('click', () => board.close());
const form = document.querySelector('#quote');
const printButton = document.querySelector('#print');
form?.addEventListener('submit', event => {
  event.preventDefault();
  const area = form.elements.namedItem('length').valueAsNumber * form.elements.namedItem('width').valueAsNumber;
  const gross = area * (1 + form.elements.namedItem('loss').valueAsNumber / 100);
  const price = Number(form.dataset.rate);
  document.querySelector('#estimate').textContent = '净面积 ' + area.toFixed(2) + ' ㎡ · 含损耗 ' + gross.toFixed(2) + ' ㎡ × ¥' + price + '/㎡ · 材料估价 ¥' + (gross * price).toFixed(2);
  printButton.hidden = false;
});
form?.addEventListener('input', () => {
  document.querySelector('#estimate').textContent = '';
  printButton.hidden = true;
});
printButton?.addEventListener('click', () => window.print());
